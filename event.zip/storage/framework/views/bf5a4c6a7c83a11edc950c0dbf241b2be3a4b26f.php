<?php echo $__env->make('backend.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH H:\xampp\htdocs\Laravel_event\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>