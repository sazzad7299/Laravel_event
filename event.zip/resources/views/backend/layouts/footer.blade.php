@include('backend.layouts.script')
@stack('scripts')
</body>
</html>